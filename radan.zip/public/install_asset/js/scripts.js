(function($) {
    "use strict";
	
	$(".select2").select2();

})(jQuery);