<form method="post" class="ajax-screen-submit" autocomplete="off" action="<?php echo e(route('branch_accounts.store')); ?>" enctype="multipart/form-data">
	<?php echo e(csrf_field()); ?>

	<div class="row px-2">
		<div class="col-md-12">
			<div class="form-group">
				<label class="control-label"><?php echo e(_lang('Account Name')); ?></label>
				<input type="text" class="form-control" name="account_name" value="<?php echo e(old('account_name')); ?>" required>
			</div>
		</div>

		<div class="col-md-12">
			<div class="form-group">
				<label class="control-label"><?php echo e(_lang('Account Type')); ?></label>
				<input type="text" class="form-control" name="account_type" value="<?php echo e(old('account_type')); ?>" required>
			</div>
		</div>

		<div class="col-md-12">
			<div class="form-group">
				<label class="control-label"><?php echo e(_lang('Branch')); ?></label>
				<select class="form-control select2" name="branch" required>
					<option value=""><?php echo e(_lang('Select Branch')); ?></option>
					<?php $__currentLoopData = App\Models\Branch::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option name="branch" value="<?php echo e($branch->id); ?>"> (<?php echo e($branch->name); ?>)</option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
		</div>

		<div class="col-md-12">
			<div class="form-group">
				<label class="control-label"><?php echo e(_lang('Opeaning Balance')); ?></label>
				<input type="number" class="form-control" name="balance" value="<?php echo e(old('balance')); ?>">

			</div>
		</div>

		<div class="col-md-12">
			<div class="form-group">
				<button type="submit" class="btn btn-primary "><i class="ti-check-box"></i>&nbsp;<?php echo e(_lang('Save')); ?></button>
			</div>
		</div>
	</div>
</form><?php /**PATH C:\xampp\htdocs\radan\resources\views/backend/branch/branch_accounts/create.blade.php ENDPATH**/ ?>