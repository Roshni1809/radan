<form method="post" class="ajax-screen-submit" autocomplete="off" action="<?php echo e(route('branch_account_transactions.store')); ?>" enctype="multipart/form-data">
	<?php echo e(csrf_field()); ?>

	<div class="row px-2">

		<!-- Branch Dropdown -->
		<div class="col-md-12">
			<div class="form-group">
				<label class="control-label"><?php echo e(_lang('Branch')); ?></label>
				<select class="form-control select2" id="branch-select" name="branch" required>
					<option value=""><?php echo e(_lang('Select Branch')); ?></option>
					<?php $__currentLoopData = App\Models\Branch::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($branch->id); ?>"> (<?php echo e($branch->name); ?>)</option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
		</div>

		<!-- Branch Account Dropdown (Initially Disabled) -->
		<div class="col-md-12">
			<div class="form-group">
				<label class="control-label"><?php echo e(_lang('Branch Account')); ?></label>
				<select class="form-control select2" id="branch-account-select" name="branch_account" required disabled>
					<option value=""><?php echo e(_lang('Select Account')); ?></option>
				</select>
			</div>
		</div>

		<!-- Amount Input -->
		<div class="col-md-12">
			<div class="form-group">
				<label class="control-label"><?php echo e(_lang('Amount')); ?></label>
				<input type="number" class="form-control" name="amount" value="<?php echo e(old('Amount')); ?>" required>
			</div>
		</div>

		<div class="col-md-12">
			<div class="form-group">
				<label class="control-label"><?php echo e(_lang('Transaction Type')); ?></label>
				<select class="form-control" name="transaction_type" required>
					<option value=""><?php echo e(_lang('Select Transaction Type')); ?></option>
					<option value="debit"><?php echo e(_lang('Debit')); ?></option>
					<option value="credit"><?php echo e(_lang('Credit')); ?></option>
				</select>
			</div>
		</div>


		<!-- Submit Button -->
		<div class="col-md-12">
			<div class="form-group">
				<button type="submit" class="btn btn-primary "><i class="ti-check-box"></i>&nbsp;<?php echo e(_lang('Save')); ?></button>
			</div>
		</div>
	</div>
</form>

<script type="text/javascript">
	$(document).ready(function() {
		// When a branch is selected
		$('#branch-select').on('change', function() {
			var branchId = $(this).val();

			// Disable the Branch Account dropdown while fetching data
			$('#branch-account-select').prop('disabled', true).empty().append('<option value=""><?php echo e(_lang('Select Account')); ?></option>');

			// Only proceed if a valid branch ID is selected
			if (branchId) {
				// Make an AJAX request to fetch branch accounts
				$.ajax({
					url: '<?php echo e(route('branch.accounts')); ?>', // Define this route in your web.php
					type: 'GET',
					data: {
						branch_id: branchId
					},
					success: function(response) {
						// Populate the Branch Account dropdown with accounts
						if (response.length > 0) {
							$.each(response, function(index, account) {
								$('#branch-account-select').append('<option value="' + account.id + '">' + account.account_name + '</option>');
							});
							$('#branch-account-select').prop('disabled', false); // Enable dropdown
						}
					},
					error: function() {
						alert('Error fetching branch accounts. Please try again.');
					}
				});
			}
		});
	});
</script><?php /**PATH C:\xampp\htdocs\radan\resources\views/backend/branch/branch_transactions/create.blade.php ENDPATH**/ ?>