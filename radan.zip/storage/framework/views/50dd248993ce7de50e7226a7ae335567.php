<table class="table table-bordered">
	<tr><td><?php echo e(_lang('Account Name')); ?></td><td><?php echo e($account->account_name); ?></td></tr>
	<tr><td><?php echo e(_lang('Account Type')); ?></td><td><?php echo e($account->account_type); ?></td></tr>
	<tr><td><?php echo e(_lang('Branch')); ?></td><td><?php echo e($account->branch->name); ?></td></tr>
	<tr><td><?php echo e(_lang('Balance')); ?></td><td><?php echo e($account->amount); ?></td></tr>
</table>
<?php /**PATH C:\xampp\htdocs\radan\resources\views/backend/branch/branch_accounts/view.blade.php ENDPATH**/ ?>