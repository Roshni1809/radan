<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-xl-3 col-md-6">
		<div class="card mb-4 primary-card dashboard-card">
			<div class="card-body">
				<div class="d-flex">
					<div class="flex-grow-1">
						<h5><?php echo e(_lang('Total Members')); ?></h5>
						<h4 class="pt-1 mb-0"><b><?php echo e($total_customer); ?></b></h4>
					</div>
					<div>
						<a href="<?php echo e(route('members.index')); ?>"><i class="ti-arrow-right"></i>&nbsp;<?php echo e(_lang('View')); ?></a>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="col-xl-3 col-md-6">
		<div class="card mb-4 success-card dashboard-card">
			<div class="card-body">
				<div class="d-flex">
					<div class="flex-grow-1">
						<h5><?php echo e(_lang('Deposit Requests')); ?></h5>
						<h4 class="pt-1 mb-0"><b><?php echo e(request_count('deposit_requests')); ?></b></h4>
					</div>
					<div>
						<a href="<?php echo e(route('deposit_requests.index')); ?>"><i class="ti-arrow-right"></i>&nbsp;<?php echo e(_lang('View')); ?></a>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="col-xl-3 col-md-6">
		<div class="card mb-4 warning-card dashboard-card">
			<div class="card-body">
				<div class="d-flex">
					<div class="flex-grow-1">
						<h5><?php echo e(_lang('Withdraw Requests')); ?></h5>
						<h4 class="pt-1 mb-0"><b><?php echo e(request_count('withdraw_requests')); ?></b></h4>
					</div>
					<div>
						<a href="<?php echo e(route('withdraw_requests.index')); ?>"><i class="ti-arrow-right"></i>&nbsp;<?php echo e(_lang('View')); ?></a>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="col-xl-3 col-md-6">
		<div class="card mb-4 danger-card dashboard-card">
			<div class="card-body">
				<div class="d-flex">
					<div class="flex-grow-1">
						<h5><?php echo e(_lang('Pending Loans')); ?></h5>
						<h4 class="pt-1 mb-0"><b><?php echo e(request_count('pending_loans')); ?></b></h4>
					</div>
					<div>
						<a href="<?php echo e(route('loans.index')); ?>"><i class="ti-arrow-right"></i>&nbsp;<?php echo e(_lang('View')); ?></a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="row">
	<div class="col-md-4 col-sm-5 mb-4">
		<div class="card h-100">
			<div class="card-header d-flex align-items-center">
				<span><?php echo e(_lang('Expense Overview').' - '.date('M Y')); ?></span>
			</div>
			<div class="card-body">
				<canvas id="expenseOverview"></canvas>
			</div>
		</div>
	</div>

	<div class="col-md-8 col-sm-7 mb-4">
		<div class="card h-100">
			<div class="card-header d-flex align-items-center">
				<span><?php echo e(_lang('Deposit & Withdraw Analytics').' - '.date('Y')); ?></span>
				<select class="filter-select ml-auto py-0 auto-select" data-selected="<?php echo e(base_currency_id()); ?>">
					<?php $__currentLoopData = \App\Models\Currency::where('status',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($currency->id); ?>" data-symbol="<?php echo e(currency($currency->name)); ?>"><?php echo e($currency->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
			<div class="card-body">
				<canvas id="transactionAnalysis"></canvas>
			</div>
		</div>
	</div>
</div>


<div class="row">
	<div class="col-md-12 mb-4">
		<div class="card mb-4">
			<div class="card-header">
				<?php echo e(_lang('Due Loan Payments')); ?>

			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table class="table table-bordered">
						<thead>
							<tr>
								<th class="text-nowrap"><?php echo e(_lang('Loan ID')); ?></th>
								<th class="text-nowrap"><?php echo e(_lang('Member No')); ?></th>
								<th class="text-nowrap"><?php echo e(_lang('Member')); ?></th>
								<th class="text-nowrap"><?php echo e(_lang('Last Payment Date')); ?></th>
								<th class="text-nowrap"><?php echo e(_lang('Due Repayments')); ?></th>
								<th class="text-nowrap text-right"><?php echo e(_lang('Total Due')); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php if(count($due_repayments) == 0): ?>
								<tr>
									<td colspan="5"><h6 class="text-center"><?php echo e(_lang('No Active Loan Available')); ?></h6></td>
								</tr>
							<?php endif; ?>

							<?php $__currentLoopData = $due_repayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $repayment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($repayment->loan->loan_id); ?></td>
								<td><?php echo e($repayment->loan->borrower->member_no); ?></td>
								<td><?php echo e($repayment->loan->borrower->name); ?></td>
								<td class="text-nowrap"><?php echo e($repayment->repayment_date); ?></td>
								<td class="text-nowrap"><?php echo e($repayment->total_due_repayment); ?></td>
								<td class="text-nowrap text-right"><?php echo e(decimalPlace($repayment->total_due, currency($repayment->loan->currency->name))); ?></td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="row">
	<div class="col-lg-12">
		<div class="card mb-4">
			<div class="card-header">
				<?php echo e(_lang('Recent Transactions')); ?>

			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table class="table table-bordered">
					<thead>
					    <tr>
						    <th><?php echo e(_lang('Date')); ?></th>
							<th><?php echo e(_lang('Member')); ?></th>
							<th class="text-nowrap"><?php echo e(_lang('Account Number')); ?></th>
							<th><?php echo e(_lang('Amount')); ?></th>
							<th class="text-nowrap"><?php echo e(_lang('Debit/Credit')); ?></th>
							<th><?php echo e(_lang('Type')); ?></th>
							<th><?php echo e(_lang('Status')); ?></th>
							<th class="text-center"><?php echo e(_lang('Action')); ?></th>
					    </tr>
					</thead>
					<tbody>
					<?php $__currentLoopData = $recent_transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php
						$symbol = $transaction->dr_cr == 'dr' ? '-' : '+';
						$class  = $transaction->dr_cr == 'dr' ? 'text-danger' : 'text-success';
						?>
						<tr>
							<td class="text-nowrap"><?php echo e($transaction->trans_date); ?></td>
							<td><?php echo e($transaction->member->name); ?></td>
							<td><?php echo e($transaction->account->account_number); ?></td>
							<td><span class="text-nowrap <?php echo e($class); ?>"><?php echo e($symbol.' '.decimalPlace($transaction->amount, currency($transaction->account->savings_type->currency->name))); ?></span></td>
							<td><?php echo e(strtoupper($transaction->dr_cr)); ?></td>
							<td><?php echo e(str_replace('_',' ',$transaction->type)); ?></td>
							<td><?php echo xss_clean(transaction_status($transaction->status)); ?></td>
							<td class="text-center"><a href="<?php echo e(route('transactions.show', $transaction->id)); ?>" target="_blank" class="btn btn-outline-primary btn-xs"><i class="ti-arrow-right"></i>&nbsp;<?php echo e(_lang('View')); ?></a></td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-script'); ?>
<script src="<?php echo e(asset('public/backend/plugins/chartJs/chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/backend/assets/js/dashboard.js?v=1.1')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\radan\resources\views/backend/dashboard-admin.blade.php ENDPATH**/ ?>