

<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-lg-12">
		<div class="card no-export">
		    <div class="card-header d-flex align-items-center">
				<span class="panel-title"><?php echo e(_lang('All Branches Accounts')); ?></span>
				<a class="btn btn-primary btn-xs ml-auto ajax-modal" data-title="<?php echo e(_lang('Add New Branch Account')); ?>" href="<?php echo e(route('branch_accounts.create')); ?>"><i class="ti-plus"></i>&nbsp;<?php echo e(_lang('Add New Account')); ?></a>
			</div>
			<div class="card-body">
				<table id="branch_account_table" class="table table-bordered data-table">
					<thead>
					    <tr>
						    <th><?php echo e(_lang('Account Name')); ?></th>
							<th><?php echo e(_lang('Account Type')); ?></th>
							<th><?php echo e(_lang('Branch')); ?></th>
							<th><?php echo e(_lang('Amount')); ?></th>
							<th class="text-center"><?php echo e(_lang('Action')); ?></th>
					    </tr>
					</thead>
					<tbody>
					    <?php $__currentLoopData = $branchAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					    <tr data-id="row_<?php echo e($account->id); ?>">
							<td class='name'><?php echo e($account->account_name); ?></td>
							<td class='contact_email'><?php echo e($account->account_type); ?></td>
							<td class='contact_phone'><?php echo e($account->branch->name); ?></td>
							<td class='contact_phone'><?php echo e($account->amount); ?></td>

							<td class="text-center">
								<span class="dropdown">
								  <button class="btn btn-primary dropdown-toggle btn-xs" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								  <?php echo e(_lang('Action')); ?>

								  
								  </button>
								  <form action="<?php echo e(route('branch_accounts.destroy', $account['id'])); ?>" method="post">
									<?php echo e(csrf_field()); ?>

									<input name="_method" type="hidden" value="DELETE">

									<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
										<a href="<?php echo e(route('branch_accounts.edit', $account['id'])); ?>" data-title="<?php echo e(_lang('Update Account')); ?>" class="dropdown-item dropdown-edit ajax-modal"><i class="ti-pencil-alt"></i>&nbsp;<?php echo e(_lang('Edit')); ?></a>
										<a href="<?php echo e(route('branch_accounts.show', $account['id'])); ?>" data-title="<?php echo e(_lang('Account Details')); ?>" class="dropdown-item dropdown-view ajax-modal"><i class="ti-eye"></i>&nbsp;<?php echo e(_lang('View Account')); ?></a>
										<button class="btn-remove dropdown-item" type="submit"><i class="ti-trash"></i>&nbsp;<?php echo e(_lang('Delete')); ?></button>
									</div>
								  </form>
								</span>
							</td>
					    </tr>
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\radan\resources\views/backend/branch/branch_accounts/list.blade.php ENDPATH**/ ?>