<ul class="breadcrumbs float-left">
    <?php    
    $routeArray = request()->route()->getAction();
    $controllerAction = $routeArray['controller'];
    list($controller, $action) = explode('@', $controllerAction);
    $segments = ''; 
    ?>

    <?php $__currentLoopData = Request::segments(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $segment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($segment == "dashboard"): ?>
            <?php continue; ?>
        <?php endif; ?>
        
        <?php $segments .= '/'.$segment; ?>
        
        <?php if(is_numeric($segment)): ?>
            <?php if(method_exists($controller, 'show')): ?>
                <?php $segment = 'View'; //continue; ?>
            <?php else: ?>
                <?php continue; ?>
            <?php endif; ?>
        <?php endif; ?>

        <?php if(! ignoreRoutes($segments)): ?>
            <?php continue; ?>
        <?php endif; ?>
        
        <?php if(! $loop->last): ?>
            <li>
                <a href="<?php echo e(url($segments)); ?>"><?php echo e(ucwords(str_replace("_"," ",$segment))); ?></a>
            </li>
        <?php else: ?>
            <li>
                <span><?php echo e(ucwords(str_replace("_"," ",$segment))); ?></span>
            </li>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH C:\xampp\htdocs\radan\resources\views/layouts/others/breadcrumbs.blade.php ENDPATH**/ ?>