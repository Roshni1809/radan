<table class="table table-bordered">
	<tr><td>{{ _lang('Account Name') }}</td><td>{{ $account->account_name }}</td></tr>
	<tr><td>{{ _lang('Account Type') }}</td><td>{{ $account->account_type }}</td></tr>
	<tr><td>{{ _lang('Branch') }}</td><td>{{ $account->branch->name }}</td></tr>
	<tr><td>{{ _lang('Balance') }}</td><td>{{ $account->amount }}</td></tr>
</table>
