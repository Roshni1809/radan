<table class="table table-bordered">
	<tr><td>{{ _lang('User Id') }}</td><td>{{ $memberdocument->user_id }}</td></tr>
					<tr><td>{{ _lang('Name') }}</td><td>{{ $memberdocument->name }}</td></tr>
					<tr><td>{{ _lang('Document') }}</td><td>{{ $memberdocument->document }}</td></tr>
</table>

