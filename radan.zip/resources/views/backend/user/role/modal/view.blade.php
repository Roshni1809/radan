<table class="table table-bordered">
	<tr><td>{{ _lang('Name') }}</td><td>{{ $role->name }}</td></tr>
					<tr><td>{{ _lang('Description') }}</td><td>{{ $role->description }}</td></tr>
</table>

